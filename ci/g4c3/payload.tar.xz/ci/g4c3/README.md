# MiniFish G4c-3 CDP regression diagnostics (Draft-only)

- Base PR #46 SHA `903769a8639b0b3517140c89c40c590a9b884d97`.
- Apply PR #46's original scripted fixture patch, then G4c browser-only patch to the ephemeral GitHub Actions checkout.
- `main`, PR #41 and PR #46 remain untouched. Never merge this diagnostic branch.
- Zero live Cloudflare, no external account login or AI API calls. Tests use synthetic localhost/HTML only.
- All four JUnit phases must pass and acceptance token `G4C3_FULL_REGRESSION_ACCEPTED` must appear in the verifier log.
- Skip in full suite retains SKIP status, strict targeted phases allow no skips.

Preflight: Chrome/Chromium executable must be available to local CDP tests. Runner may have Google Chrome installed; tests dynamically locate it.
