from __future__ import annotations
from pathlib import Path
import os
import sys
import xml.etree.ElementTree as ET

BASE = Path('ci-evidence')
NAMES = ['01-scripted', '02-pr40-pr41', '03-all', '04-g4c']
PHASES = ['PHASE1', 'PHASE2', 'PHASE3', 'PHASE4']
required = {
    'test_issue_to_browser_to_sanitized_receipt',
    'test_private_titles_are_exact_and_vault_bytes_are_unchanged',
    'test_without_fake_login_cookie_read_is_blocked',
    'test_issue_to_private_one_time_receiver_with_zero_public_data',
}

def case_id(c):
    return (c.get('classname'), c.get('name'))

def main():
    groups = []
    errors = []
    for stem, phase in zip(NAMES, PHASES):
        path = BASE / (stem + '.xml')
        if not path.is_file():
            print(stem, 'NO_JUNIT')
            errors.append(stem + ': NO_JUNIT')
            groups.append([])
            continue
        try:
            cases = ET.parse(path).getroot().findall('.//testcase')
        except Exception as exc:
            print(stem, 'INVALID_JUNIT', type(exc).__name__)
            errors.append(stem + ': INVALID_JUNIT')
            groups.append([])
            continue
        fails = [c for c in cases if c.find('failure') is not None or c.find('error') is not None]
        skips = [c for c in cases if c.find('skipped') is not None]
        passed = len(cases)-len(fails)-len(skips)
        print(f'{stem}: collected={len(cases)} PASS={passed} FAIL={len(fails)} SKIP={len(skips)} outcome={os.getenv(phase)}')
        if fails or os.getenv(phase) != 'success':
            errors.append(stem + ': FAILED')
        if stem != '03-all' and skips:
            errors.append(stem + ': UNEXPECTED_SKIP')
        groups.append(cases)

    a,b,c,d=groups
    if len(a) != 54: errors.append('SCRIPTED_CASE_COUNT_NOT_54')
    if len(b) < 21: errors.append('PR40_PR41_CASES_UNDER_21')
    if len(d) != 27: errors.append('G4C_CASE_COUNT_NOT_27')
    full_ids = {case_id(x) for x in c}
    for name, group in [('scripted',a), ('pr41',b), ('g4c',d)]:
        missing={case_id(x) for x in group}-full_ids
        if missing: errors.append(name+': NOT_INCLUDED_IN_FULL_SUITE')
    for label, group in [('PR41', b), ('FULL',c)]:
        passed_names={x.get('name') for x in group if all(x.find(t) is None for t in ('failure','error','skipped'))}
        if not required.issubset(passed_names): errors.append(label+': FOUR_REQUIRED_NOT_ALL_PASS')
    for e in errors: print('HOLD:',e)
    if errors:
        raise SystemExit('G4C3_FULL_REGRESSION_HOLD')
    print('G4C3_FULL_REGRESSION_ACCEPTED: 54 scripted, PR40/41>=21, G4c27, full suite covers all')

if __name__ == '__main__': main()
