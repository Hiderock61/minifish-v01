"""G4c additional integration-boundary regressions for exact MiniFish browser.
All CDP connections point at local ephemeral Chromium. No cloud or real websites.
"""
import os
import sys
import subprocess
import tempfile
import shutil
from pathlib import Path

import pytest
from cryptography.fernet import Fernet
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'repo'))
from minifish.browser import PlaywrightBrowser
from minifish.models import Action
from minifish.session_vault import EncryptedSessionVault
from g4_cdp_probe import spawn_cdp, FIXTURE


@pytest.fixture(autouse=True)
def clean_env(monkeypatch):
    for key in ('MINIFISH_CDP_ENDPOINT', 'MINIFISH_CDP_CONTEXT',
                'MINIFISH_CDP_API_TOKEN', 'MINIFISH_BROWSER_TRANSPORT'):
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv('MINIFISH_CHROMIUM_PATH', shutil.which('chromium') or shutil.which('google-chrome') or os.getenv('MINIFISH_CHROMIUM_PATH', '/nonexistent'))


@pytest.fixture(scope='module')
def cdp():
    with tempfile.TemporaryDirectory(prefix='g4c-cdp-') as td:
        p,port=spawn_cdp(Path(td))
        try:
            yield p, f'http://127.0.0.1:{port}'
        finally:
            if p.poll() is None:
                p.terminate()
                try: p.wait(timeout=5)
                except subprocess.TimeoutExpired: p.kill(); p.wait(timeout=5)


def count_pages(endpoint):
    with sync_playwright() as pw:
        browser=pw.chromium.connect_over_cdp(endpoint)
        try:
            return len(browser.contexts[0].pages),len(browser.contexts)
        finally: browser.close()


def setup(monkeypatch,cdp,mode='default'):
    monkeypatch.setenv('MINIFISH_BROWSER_TRANSPORT','cdp')
    monkeypatch.setenv('MINIFISH_CDP_ENDPOINT',cdp[1])
    monkeypatch.setenv('MINIFISH_CDP_CONTEXT',mode)


def test_default_context_normal_finish_does_not_leak_tab(monkeypatch,cdp):
    setup(monkeypatch,cdp)
    before=count_pages(cdp[1])
    with PlaywrightBrowser() as client:
        client.page.set_content(FIXTURE)
        client.execute(Action(type='fill', name='表示名',value='G4c'))
        client.execute(Action(type='click',role='button',name='保存'))
        assert '保存完了: G4c' in client.observe().text_excerpt
    assert count_pages(cdp[1])==before
    assert cdp[0].poll() is None


def test_default_context_exception_does_not_leak_tab(monkeypatch,cdp):
    setup(monkeypatch,cdp)
    before=count_pages(cdp[1])
    with pytest.raises(RuntimeError,match='SYNTHETIC_JOB_FAILURE'):
        with PlaywrightBrowser() as client:
            client.page.set_content('<title>synthetic-failure</title>')
            raise RuntimeError('SYNTHETIC_JOB_FAILURE')
    assert count_pages(cdp[1])==before


def test_default_context_does_not_close_existing_owner_tabs(monkeypatch,cdp):
    setup(monkeypatch,cdp)
    with sync_playwright() as pw:
        owner = pw.chromium.connect_over_cdp(cdp[1])
        try:
            t=owner.contexts[0].new_page()
            t.set_content('<html><head><title>OWNER_UNTOUCHED</title></head><body>owner</body></html>')
        finally: owner.close()
    before=count_pages(cdp[1])
    try:
        with PlaywrightBrowser() as client:
            client.page.set_content('<title>MiniFish isolated tab</title>')
        assert count_pages(cdp[1])==before
        with sync_playwright() as pw:
            check=pw.chromium.connect_over_cdp(cdp[1])
            try:
                assert sum(p.title()=='OWNER_UNTOUCHED' for p in check.contexts[0].pages)==1
            finally: check.close()
    finally:
        with sync_playwright() as pw:
            cleanup=pw.chromium.connect_over_cdp(cdp[1])
            try:
                for p in cleanup.contexts[0].pages:
                    if p.title()=='OWNER_UNTOUCHED': p.close()
            finally: cleanup.close()


def test_new_context_exits_without_leaving_context(monkeypatch,cdp):
    setup(monkeypatch,cdp,mode='new')
    before=count_pages(cdp[1])
    with PlaywrightBrowser() as client:
        assert len(client.browser.contexts)==before[1]+1
        client.page.set_content('<title>new-context-job</title>')
    assert count_pages(cdp[1])==before
    assert cdp[0].poll() is None


def test_remote_new_context_vault_read_only_restoration(monkeypatch,cdp,tmp_path):
    setup(monkeypatch,cdp,mode='new')
    protected=tmp_path/'private'
    protected.mkdir(mode=0o700)
    vault=EncryptedSessionVault(protected/'vault.bin',Fernet.generate_key())
    cookie={'name':'test_only_cookie','value':'G4c','domain':'127.0.0.1',
            'path':'/','expires':-1,'httpOnly':True,'secure':False,'sameSite':'Lax'}
    vault.save({'cookies':[cookie], 'origins':[]})
    before=vault.path.read_bytes()
    with PlaywrightBrowser(session_vault=vault,save_session_on_exit=False) as browser:
        cookies=browser.context.cookies()
        assert any(c['name']=='test_only_cookie' and c['value']=='G4c' for c in cookies)
        browser.page.set_content('<title>test</title>')
    assert vault.path.read_bytes()==before


def test_local_default_never_uses_remote_endpoint(monkeypatch,cdp):
    monkeypatch.setenv('MINIFISH_BROWSER_TRANSPORT','local')
    monkeypatch.setenv('MINIFISH_CDP_ENDPOINT','https://evil.invalid/secret')
    with PlaywrightBrowser() as client:
        assert client._owns_context
        client.page.set_content('<title>LOCAL_NOT_CDP</title>')
        assert client.observe().title == 'LOCAL_NOT_CDP'


def test_replayed_default_cdps_do_not_accumulate_tabs(monkeypatch,cdp):
    setup(monkeypatch,cdp)
    before=count_pages(cdp[1])
    for i in range(3):
        with PlaywrightBrowser() as client:
            client.page.set_content(f'<title>run-{i}</title>')
            assert client.observe().title == f'run-{i}'
        assert count_pages(cdp[1])==before
