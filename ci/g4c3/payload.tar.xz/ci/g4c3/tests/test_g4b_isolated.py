"""G4b tests of the *blob-exact PR46 browser.py* plus isolated CDP switch.
No external websites, no Cloudflare access, no GitHub writes.
"""
import os
import subprocess
import tempfile
from pathlib import Path
import sys
import time
import shutil

import pytest
from cryptography.fernet import Fernet

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'repo'))

from minifish.browser import PlaywrightBrowser
from minifish.models import Action
from minifish.session_vault import EncryptedSessionVault
from g4_cdp_probe import spawn_cdp, FIXTURE

CHROME = shutil.which('chromium') or shutil.which('google-chrome') or os.getenv('MINIFISH_CHROMIUM_PATH')

@pytest.fixture(autouse=True)
def clear_transport_env(monkeypatch):
    for k in ('MINIFISH_BROWSER_TRANSPORT', 'MINIFISH_CDP_ENDPOINT',
              'MINIFISH_CDP_CONTEXT', 'MINIFISH_CDP_API_TOKEN'):
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setenv('MINIFISH_CHROMIUM_PATH', CHROME)

@pytest.fixture(scope='module')
def live_local_cdp():
    with tempfile.TemporaryDirectory(prefix='g4b-cdp-') as td:
        proc, port = spawn_cdp(Path(td))
        try:
            yield port
        finally:
            if proc.poll() is None:
                proc.terminate()
                try: proc.wait(timeout=5)
                except subprocess.TimeoutExpired: proc.kill(); proc.wait(timeout=5)

def exercise(b):
    # Exercise the actual MiniFish browser.execute and observe methods.
    req=[]
    b.page.route('**/*', lambda route: (req.append(route.request.url), route.abort()))
    b.page.set_content(FIXTURE, wait_until='domcontentloaded')
    assert b.observe().title == 'MiniFish G4 synthetic form'
    a = Action(type='fill', name='表示名', value='fish-G4b')
    assert b.execute(a)['ok']
    c = Action(type='click', role='button', name='保存')
    assert b.execute(c)['ok']
    observation = b.observe()
    assert '保存完了: fish-G4b' in observation.text_excerpt
    assert '保存完了' in observation.aria_snapshot
    assert b.page.screenshot(full_page=True).startswith(b'\x89PNG')
    assert not req
    return observation.title, observation.text_excerpt


def test_local_launch_browser_unchanged():
    with PlaywrightBrowser() as browser:
        title, text = exercise(browser)
        assert title == 'MiniFish G4 synthetic form'


def test_cdp_new_context_runs_real_minifish_browser(monkeypatch, live_local_cdp):
    monkeypatch.setenv('MINIFISH_BROWSER_TRANSPORT','cdp')
    monkeypatch.setenv('MINIFISH_CDP_ENDPOINT',f'http://127.0.0.1:{live_local_cdp}')
    with PlaywrightBrowser() as browser:
        assert browser._owns_context is True
        exercise(browser)


def test_cdp_default_context_runs_real_minifish_browser(monkeypatch, live_local_cdp):
    monkeypatch.setenv('MINIFISH_BROWSER_TRANSPORT','cdp')
    monkeypatch.setenv('MINIFISH_CDP_CONTEXT','default')
    monkeypatch.setenv('MINIFISH_CDP_ENDPOINT',f'http://127.0.0.1:{live_local_cdp}')
    with PlaywrightBrowser() as browser:
        assert browser._owns_context is False
        exercise(browser)


def test_cdp_unavailable_stops_with_fixed_code(monkeypatch):
    monkeypatch.setenv('MINIFISH_BROWSER_TRANSPORT','cdp')
    monkeypatch.setenv('MINIFISH_CDP_ENDPOINT','http://127.0.0.1:9')
    started = time.monotonic()
    with pytest.raises(RuntimeError, match='^CDP_CONNECTION_FAILED$'):
        with PlaywrightBrowser(): pass
    assert time.monotonic() - started < 15

@pytest.mark.parametrize('bad',[
    'https://example.org/cdp',
    'wss://example.org/cdp',
    'http://127.0.0.1:8181/path',
    'http://127.0.0.1:8181?token=secret',
    'http://127.0.0.1:8181/#fragment',
    'http://user:pass@127.0.0.1:8181',
])
def test_reject_unapproved_endpoints_before_network(monkeypatch,bad):
    monkeypatch.setenv('MINIFISH_BROWSER_TRANSPORT','cdp')
    monkeypatch.setenv('MINIFISH_CDP_ENDPOINT',bad)
    with pytest.raises(ValueError,match='^CDP_ENDPOINT_'):
        with PlaywrightBrowser(): pass

@pytest.mark.parametrize('bad',[
    'wss://api.cloudflare.com/client/v4/accounts/'+'a'*32+'/browser-rendering/devtools/browser?keep_alive=999999',
    'wss://api.cloudflare.com/client/v4/accounts/'+'a'*32+'/browser-rendering/devtools/browser?keep_alive=60000&foo=x',
])
def test_cdp_cloudflare_rejects_unsafe_keepalive_without_connect(monkeypatch,bad):
    monkeypatch.setenv('MINIFISH_BROWSER_TRANSPORT','cdp')
    monkeypatch.setenv('MINIFISH_CDP_ENDPOINT',bad)
    monkeypatch.setenv('MINIFISH_CDP_API_TOKEN','dummy-not-real')
    with pytest.raises(ValueError,match='^CDP_KEEP_ALIVE_UNSAFE$'):
        with PlaywrightBrowser(): pass


def test_cdp_cloudflare_requires_private_token_without_connect(monkeypatch):
    monkeypatch.setenv('MINIFISH_BROWSER_TRANSPORT','cdp')
    monkeypatch.setenv('MINIFISH_CDP_ENDPOINT','wss://api.cloudflare.com/client/v4/accounts/'+'a'*32+'/browser-rendering/devtools/browser?keep_alive=60000')
    with pytest.raises(ValueError,match='^CDP_TOKEN_REQUIRED$'):
        with PlaywrightBrowser(): pass


def test_default_context_never_imports_vault(monkeypatch,tmp_path):
    vault_dir=tmp_path/'private'
    vault_dir.mkdir(mode=0o700)
    v=EncryptedSessionVault(vault_dir/'session.bin',Fernet.generate_key())
    v.save({'cookies':[], 'origins':[]})
    monkeypatch.setenv('MINIFISH_BROWSER_TRANSPORT','cdp')
    monkeypatch.setenv('MINIFISH_CDP_ENDPOINT','http://127.0.0.1:9')
    monkeypatch.setenv('MINIFISH_CDP_CONTEXT','default')
    with pytest.raises(ValueError,match='^CDP_DEFAULT_CONTEXT_AUTH_STATE_BLOCKED$'):
        with PlaywrightBrowser(session_vault=v): pass


def test_encrypted_vault_read_only_is_byte_unchanged(tmp_path):
    d=tmp_path/'private'
    d.mkdir(mode=0o700)
    v=EncryptedSessionVault(d/'session.bin',Fernet.generate_key())
    v.save({'cookies':[], 'origins':[]})
    old=v.path.read_bytes()
    with PlaywrightBrowser(session_vault=v,save_session_on_exit=False) as b:
        exercise(b)
    assert v.path.read_bytes()==old


def test_invalid_vault_fails_before_opening_remote_connection(monkeypatch,tmp_path):
    d=tmp_path/'private'; d.mkdir(mode=0o700)
    v=EncryptedSessionVault(d/'session.bin',Fernet.generate_key())
    v.save({'cookies':[], 'origins':[]})
    v.path.write_bytes(b'corrupt')
    monkeypatch.setenv('MINIFISH_BROWSER_TRANSPORT','cdp')
    monkeypatch.setenv('MINIFISH_CDP_ENDPOINT','http://127.0.0.1:9')
    with pytest.raises(ValueError,match='^SESSION_VAULT_DECRYPT_FAILED$'):
        with PlaywrightBrowser(session_vault=v): pass


def test_bad_transport_refuses_to_start(monkeypatch):
    monkeypatch.setenv('MINIFISH_BROWSER_TRANSPORT','magic')
    with pytest.raises(ValueError,match='^BROWSER_TRANSPORT_INVALID$'):
        with PlaywrightBrowser(): pass


def test_private_cloudflare_token_transmitted_in_header_only_and_error_is_redacted(monkeypatch):
    """No network: fake CDP handshake to ensure auth and one-shot failure semantics."""
    import traceback
    import minifish.browser as browser_module
    secret='g4b-example-test-secret-never-live'
    endpoint='wss://api.cloudflare.com/client/v4/accounts/'+'b'*32+'/browser-rendering/devtools/browser?keep_alive=60000'
    calls=[]
    class FakeChromium:
        def connect_over_cdp(self,url,**options):
            calls.append((url,options))
            raise RuntimeError('simulated failure '+secret)
    class FakeRuntime:
        chromium=FakeChromium()
        def stop(self): pass
    class FakeStarter:
        def start(self): return FakeRuntime()
    monkeypatch.setattr(browser_module, 'sync_playwright', lambda: FakeStarter())
    monkeypatch.setenv('MINIFISH_BROWSER_TRANSPORT','cdp')
    monkeypatch.setenv('MINIFISH_CDP_ENDPOINT',endpoint)
    monkeypatch.setenv('MINIFISH_CDP_API_TOKEN',secret)
    with pytest.raises(RuntimeError,match='^CDP_CONNECTION_FAILED$') as e:
        with PlaywrightBrowser(): pass
    assert len(calls)==1, 'no hidden automatic retries'
    assert secret not in calls[0][0]
    assert calls[0][1]['headers']['Authorization']=='Bearer '+secret
    assert calls[0][1]['timeout']==8000
    assert secret not in str(e.value)
    assert secret not in ''.join(traceback.format_exception(e.value))


def test_default_cdp_context_blocks_plaintext_profile(monkeypatch,tmp_path):
    monkeypatch.setenv('MINIFISH_BROWSER_TRANSPORT','cdp')
    monkeypatch.setenv('MINIFISH_CDP_ENDPOINT','http://127.0.0.1:9')
    monkeypatch.setenv('MINIFISH_CDP_CONTEXT','default')
    with pytest.raises(ValueError,match='^CDP_DEFAULT_CONTEXT_AUTH_STATE_BLOCKED$'):
        with PlaywrightBrowser(profile_path=str(tmp_path/'profile.json')): pass


def test_vault_ordinary_local_save_still_works(tmp_path):
    d=tmp_path/'private'
    d.mkdir(mode=0o700)
    v=EncryptedSessionVault(d/'session.bin',Fernet.generate_key())
    v.save({'cookies':[], 'origins':[]})
    first=v.path.read_bytes()
    with PlaywrightBrowser(session_vault=v) as b:
        exercise(b)
    assert v.load() == {'cookies':[], 'origins':[]}
    assert v.path.read_bytes()!=first
