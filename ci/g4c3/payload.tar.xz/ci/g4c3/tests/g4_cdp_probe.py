"""MiniFish G4 transport-only proof. No cloud calls, no credentials, no repo mutation.
This deliberately reproduces the Playwright calls seen in minifish/browser.py; it
is NOT a patch to the connected GitHub repo or an end-to-end MiniFish integration.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
CHROME = shutil.which("chromium") or shutil.which("google-chrome") or os.getenv("MINIFISH_CHROMIUM_PATH")
FIXTURE = """<!doctype html><html lang='ja'><head><meta charset='utf-8'>
<title>MiniFish G4 synthetic form</title></head><body>
<label for='display'>表示名</label><input id='display' />
<button id='save' onclick='document.querySelector("#status").textContent="保存完了: " + document.querySelector("#display").value'>保存</button>
<div id='status'>未保存</div></body></html>"""


def exercise(browser, mode: str, ctx_choice: str):
    # Actual operations are the same as minifish/browser.py's page-based calls.
    started = time.monotonic()
    existing = browser.contexts
    if ctx_choice == 'default':
        assert existing, "CDP default context missing"
        context = existing[0]
        managed_context = False
    else:
        context = browser.new_context()
        managed_context = True
    page = context.new_page()
    # Strict browser-layer network guard for this local-only fixture.
    requests = []
    page.route("**/*", lambda route: (requests.append(route.request.url), route.abort()))
    try:
        page.set_content(FIXTURE, wait_until="domcontentloaded")
        assert page.title() == "MiniFish G4 synthetic form"
        page.get_by_label("表示名", exact=True).fill("fish-G4")
        page.get_by_role("button", name="保存", exact=True).click()
        observed = page.locator("#status").inner_text()
        aria = page.locator("body").aria_snapshot(timeout=3000)
        png = page.screenshot(full_page=True)
        assert observed == "保存完了: fish-G4", observed
        assert "保存完了" in aria
        assert not requests, "unexpected network attempts"
        return {
            "case": mode,
            "context": ctx_choice,
            "status": "PASS",
            "actions": ["set_content", "fill", "click", "observe", "screenshot"],
            "observed_title": page.title(),
            "observed_status": observed,
            "aria_contains_result": True,
            "screenshot_bytes": len(png),
            "external_http_requests": len(requests),
            "elapsed_ms": round((time.monotonic() - started) * 1000),
        }
    finally:
        page.close()
        if managed_context:
            context.close()


def spawn_cdp(user_dir: Path):
    argv = [CHROME, "--headless=new", "--no-sandbox", "--disable-dev-shm-usage", "--no-first-run", "--no-default-browser-check", "--remote-debugging-address=127.0.0.1", "--remote-debugging-port=0", "--user-data-dir="+str(user_dir), "about:blank"]
    proc = subprocess.Popen(argv, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    port_path = user_dir / "DevToolsActivePort"
    for _ in range(120):
        if port_path.is_file():
            port=int(port_path.read_text().splitlines()[0]); return proc, port
        if proc.poll() is not None:
            raise RuntimeError(f"Chromium CDP subprocess exited: {proc.returncode}")
        time.sleep(.1)
    proc.terminate()
    raise TimeoutError("Chromium did not expose local CDP endpoint")


def main():
    assert CHROME, "Chromium is not installed"
    results=[]
    with sync_playwright() as pw:
        # Control: MiniFish main's launch() mode.
        b=pw.chromium.launch(headless=True, executable_path=CHROME, args=["--no-sandbox","--disable-dev-shm-usage"])
        try: results.append(exercise(b, 'local-launch-control', 'new'))
        finally: b.close()

        # Treatment: external Chromium controlled via the very same CDP API.
        with tempfile.TemporaryDirectory(prefix="minifish-g4-cdp-") as td:
            proc, port=spawn_cdp(Path(td))
            try:
                b=pw.chromium.connect_over_cdp(f"http://127.0.0.1:{port}", timeout=10000)
                try:
                    results.append(exercise(b,'local-cdp-existing-context','default'))
                    results.append(exercise(b,'local-cdp-new-context','new'))
                finally: b.close()
            finally:
                if proc.poll() is None:
                    proc.terminate()
                    try: proc.wait(timeout=5)
                    except subprocess.TimeoutExpired: proc.kill(); proc.wait(timeout=5)

        # Failure mode: bounded timeout, no retry, no secret/URL in report.
        t=time.monotonic()
        try:
            b=pw.chromium.connect_over_cdp("http://127.0.0.1:9", timeout=1200)
            b.close()
            raise AssertionError("unexpected connection to unreachable port")
        except Exception as exc:
            if isinstance(exc, AssertionError):raise
            results.append({"case":"cdp-unreachable-fail-closed", "status":"PASS", "error_class":type(exc).__name__,"elapsed_ms":round((time.monotonic()-t)*1000),"retries":0})

    matches=(results[0]['observed_title']==results[1]['observed_title']==results[2]['observed_title'] and results[0]['observed_status']==results[1]['observed_status']==results[2]['observed_status'])
    report={"contract":"MiniFish-G4-local-CDP-transport-proof-v0.1", "date":"2026-11-15", "main_github_modified":False,"cloudflare_api_called":False,"github_actions_triggered":False,"credentials_accessed":False,"transport_parity":matches,"environment":{"python":"3.13","chromium":subprocess.check_output([CHROME,'--version'],text=True).strip()},"tests":results,"all_pass":matches and all(x['status']=='PASS' for x in results),"scope_limit":"Standalone Playwright transport equivalence only; not a complete MiniFish repo E2E or Cloudflare live connection."}
    (ROOT/'g4_local_evidence.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    assert report['all_pass']

if __name__=='__main__': main()
